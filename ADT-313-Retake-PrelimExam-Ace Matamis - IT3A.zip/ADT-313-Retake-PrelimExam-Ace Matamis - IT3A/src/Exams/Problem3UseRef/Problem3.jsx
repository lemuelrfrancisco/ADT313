import React, { useRef } from "react";

function Problem3() {
  const inputRef1 = useRef(null);
  const inputRef2 = useRef(null);
  const inputRef3 = useRef(null);
  const inputRef4 = useRef(null);
  const inputRef5 = useRef(null);
  const inputRef6 = useRef(null);
  const inputRef7 = useRef(null);
  const inputRef8 = useRef(null);
  const inputRef9 = useRef(null);
  const inputRef10 = useRef(null);

  const handleClick = () => {

    const refs = [
      inputRef1,
      inputRef2,
      inputRef3,
      inputRef4,
      inputRef5,
      inputRef6,
      inputRef7,
      inputRef8,
      inputRef9,
      inputRef10
    ];

    for (const ref of refs) {
      if (ref.current && ref.current.value === '') {
        ref.current.focus();
        break;
      }
    }
  };

  return (
    <div className="p-4">
      <div className="space-y-2">
        <div>
          Input 1: <input ref={inputRef1} type="text" className="border p-1" />
        </div>
        <div>
          Input 2: <input ref={inputRef2} type="text" className="border p-1" />
        </div>
        <div>
          Input 3: <input ref={inputRef3} type="text" className="border p-1" />
        </div>
        <div>
          Input 4: <input ref={inputRef4} type="text" className="border p-1" />
        </div>
        <div>
          Input 5: <input ref={inputRef5} type="text" className="border p-1" />
        </div>
        <div>
          Input 6: <input ref={inputRef6} type="text" className="border p-1" />
        </div>
        <div>
          Input 7: <input ref={inputRef7} type="text" className="border p-1" />
        </div>
        <div>
          Input 8: <input ref={inputRef8} type="text" className="border p-1" />
        </div>
        <div>
          Input 9: <input ref={inputRef9} type="text" className="border p-1" />
        </div>
        <div>
          Input 10: <input ref={inputRef10} type="text" className="border p-1" />
        </div>
        <button 
          onClick={handleClick}
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          I'm a Button
        </button>
      </div>
    </div>
  );
}

export default Problem3;