import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const idleTimer = useRef(null);

  useEffect(() => {
    // Dismiss loading after 3 seconds
    const loadingTimeout = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(loadingTimeout); // Cleanup on unmount
  }, []);

  function handleInputChange() {
    // User is typing
    setIsTyping(true);
    clearTimeout(idleTimer.current);

    // Set a timer to change back to idle if no typing occurs in 2 seconds
    idleTimer.current = setTimeout(() => {
      setIsTyping(false);
    }, 2000);
  }

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: <input type="text" onChange={handleInputChange} />
          <p>User is {isTyping ? 'typing...' : 'idle...'}</p>
        </div>
      )}
    </>
  );
}
