import React, { useReducer } from 'react';
import data from './problem8mock_data.json';

// Define action types
const ADD_FOOD = 'ADD_FOOD';
const UPDATE_FOOD = 'UPDATE_FOOD';
const DELETE_FOOD = 'DELETE_FOOD';
const SELECT_FOOD = 'SELECT_FOOD';
const CLEAR_SELECTION = 'CLEAR_SELECTION';

// Initial state
const initialState = {
  foods: data,
  selected: null,
};

// Reducer function
function reducer(state, action) {
  switch (action.type) {
    case ADD_FOOD:
      return { ...state, foods: [...state.foods, action.payload] };
    case UPDATE_FOOD:
      return {
        ...state,
        foods: state.foods.map((food) =>
          food.food_name === action.payload.food_name ? action.payload : food
        ),
      };
    case DELETE_FOOD:
      return {
        ...state,
        foods: state.foods.filter((food) => food.food_name !== action.payload),
      };
    case SELECT_FOOD:
      return { ...state, selected: action.payload };
    case CLEAR_SELECTION:
      return { ...state, selected: null };
    default:
      return state;
  }
}

export default function Problem8() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { foods, selected } = state;

  const handleEdit = (food) => {
    dispatch({ type: SELECT_FOOD, payload: food });
  };

  const handleDelete = (foodName) => {
    dispatch({ type: DELETE_FOOD, payload: foodName });
  };

  const handleClear = () => {
    dispatch({ type: CLEAR_SELECTION });
  };

  const handleSave = () => {
    if (selected) {
      dispatch({ type: UPDATE_FOOD, payload: selected });
    } else {
      const newFood = {
        food_name: document.getElementById('food_name').value,
        price: document.getElementById('price').value,
        expiration_date: document.getElementById('expiration_date').value,
        calories: document.getElementById('calories').value,
      };
      dispatch({ type: ADD_FOOD, payload: newFood });
    }
    handleClear(); // Clear form after save
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            id='food_name'
            type='text'
            value={selected ? selected.food_name : ''}
            onChange={(e) => dispatch({ type: SELECT_FOOD, payload: { ...selected, food_name: e.target.value } })}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            id='price'
            type='text'
            value={selected ? selected.price : ''}
            onChange={(e) => dispatch({ type: SELECT_FOOD, payload: { ...selected, price: e.target.value } })}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            id='expiration_date'
            type='text'
            value={selected ? selected.expiration_date : ''}
            onChange={(e) => dispatch({ type: SELECT_FOOD, payload: { ...selected, expiration_date: e.target.value } })}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            id='calories'
            type='text'
            value={selected ? selected.calories : ''}
            onChange={(e) => dispatch({ type: SELECT_FOOD, payload: { ...selected, calories: e.target.value } })}
          />
        </div>

        <button type='button' onClick={handleSave}>Save</button>
        <button type='button' onClick={handleClear}>Clear</button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food, index) => (
              <tr key={index}>
                <td>{food.food_name}</td>
                <td>{food .price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(food)}>Edit</button>
                  <button type='button' onClick={() => handleDelete(food.food_name)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}